# 📊 ECOLENSE INTELLIGENCE - VERİ SETİ DEĞİŞKEN AÇIKLAMALARI

## 🌍 **Veri Seti: ecolense_final_enriched_with_iso.csv**

### 📋 **Veri Seti Genel Bilgileri**
- **Dosya Adı:** ecolense_final_enriched_with_iso.csv
- **Toplam Gözlem:** 5,000
- **Toplam Değişken:** 37
- **Zaman Aralığı:** 2018-2024 (7 yıl)
- **Ülke Sayısı:** 20
- **Gıda Kategorisi:** 8

---

## 📊 **DEĞİŞKEN AÇIKLAMALARI**

### 🏛️ **TEMEL DEĞİŞKENLER (8 adet)**

#### **1. Country**
- **Açıklama:** Ülke adı
- **Veri Tipi:** String (Kategorik)
- **Örnek Değerler:** "USA", "Germany", "France", "China", "India"
- **Kapsam:** 20 ülke

#### **2. Year**
- **Açıklama:** Veri toplama yılı
- **Veri Tipi:** Integer
- **Aralık:** 2018-2024
- **Örnek Değerler:** 2018, 2019, 2020, 2021, 2022, 2023, 2024

#### **3. Food Category**
- **Açıklama:** Gıda kategorisi
- **Veri Tipi:** String (Kategorik)
- **Değerler:** 
  - "Fruits & Vegetables" (Meyve & Sebze)
  - "Prepared Food" (Hazır Gıda)
  - "Dairy Products" (Süt Ürünleri)
  - "Bakery Items" (Fırın Ürünleri)
  - "Beverages" (İçecekler)
  - "Meat & Seafood" (Et & Deniz Ürünleri)
  - "Frozen Food" (Dondurulmuş Gıda)
  - "Grains & Cereals" (Tahıl & Hububat)

#### **4. Total Waste (Tons)**
- **Açıklama:** Toplam gıda israfı miktarı (ton cinsinden)
- **Veri Tipi:** Float
- **Birim:** Ton
- **Aralık:** 1,000 - 50,000 ton
- **Hedef Değişken:** Evet (Tahmin edilecek)

#### **5. Economic Loss (Million $)**
- **Açıklama:** Ekonomik kayıp miktarı (milyon USD cinsinden)
- **Veri Tipi:** Float
- **Birim:** Milyon USD
- **Aralık:** 1,000 - 50,000 milyon USD
- **Hedef Değişken:** Evet (Tahmin edilecek)

#### **6. Avg Waste per Capita (Kg)**
- **Açıklama:** Kişi başı ortalama gıda israfı
- **Veri Tipi:** Float
- **Birim:** Kilogram
- **Aralık:** 50 - 200 kg/kişi

#### **7. Population (Million)**
- **Açıklama:** Ülke nüfusu (milyon cinsinden)
- **Veri Tipi:** Float
- **Birim:** Milyon kişi
- **Aralık:** 10 - 1,400 milyon

#### **8. Household Waste (%)**
- **Açıklama:** Evsel atık yüzdesi
- **Veri Tipi:** Float
- **Birim:** Yüzde (%)
- **Aralık:** 20 - 80%

---

### 🌍 **MATERIAL FOOTPRINT DEĞİŞKENLERİ (32 adet)**

#### **9. Material_Footprint_Per_Capita**
- **Açıklama:** Kişi başı malzeme ayak izi
- **Veri Tipi:** Float
- **Birim:** Ton/kişi
- **Kaynak:** Material Footprint Dataset

#### **10. Continent**
- **Açıklama:** Kıta bilgisi
- **Veri Tipi:** String (Kategorik)
- **Değerler:** "Asia", "Europe", "North America", "South America", "Africa", "Oceania"

#### **11. Hemisphere**
- **Açıklama:** Yarımküre bilgisi
- **Veri Tipi:** String (Kategorik)
- **Değerler:** "Northern", "Southern"

#### **12. ISO_Code**
- **Açıklama:** Ülke ISO kodu
- **Veri Tipi:** String
- **Örnek Değerler:** "USA", "DEU", "FRA", "CHN", "IND"

---

### 📊 **TÜRETİLMİŞ ÖZELLİKLER (29 adet)**

#### **Kişi Başı Metrikler (6 özellik)**

#### **13. Waste_Per_Capita_kg**
- **Açıklama:** Kişi başı gıda israfı (kg cinsinden)
- **Hesaplama:** Total Waste (Tons) * 1000 / Population (Million)
- **Veri Tipi:** Float
- **Birim:** kg/kişi

#### **14. Economic_Loss_Per_Capita_USD**
- **Açıklama:** Kişi başı ekonomik kayıp (USD cinsinden)
- **Hesaplama:** Economic Loss (Million $) * 1,000,000 / Population (Million)
- **Veri Tipi:** Float
- **Birim:** USD/kişi

#### **15. Carbon_Footprint_kgCO2e**
- **Açıklama:** Karbon ayak izi (kg CO2e cinsinden)
- **Hesaplama:** Total Waste (Tons) * 2.5 (ortalama karbon faktörü)
- **Veri Tipi:** Float
- **Birim:** kg CO2e
- **Hedef Değişken:** Evet (Tahmin edilecek)

#### **16. Carbon_Per_Capita_kgCO2e**
- **Açıklama:** Kişi başı karbon ayak izi
- **Hesaplama:** Carbon_Footprint_kgCO2e / Population (Million)
- **Veri Tipi:** Float
- **Birim:** kg CO2e/kişi

#### **17. GDP_Per_Capita_Proxy**
- **Açıklama:** Kişi başı GSYH proxy değeri
- **Hesaplama:** Economic Loss (Million $) / Population (Million) * 100
- **Veri Tipi:** Float
- **Birim:** USD/kişi

#### **18. Waste_Efficiency**
- **Açıklama:** İsraf verimliliği skoru
- **Hesaplama:** 100 - (Waste_Per_Capita_kg / 200 * 100)
- **Veri Tipi:** Float
- **Birim:** Skor (0-100)

---

#### **Zamansal Özellikler (8 özellik)**

#### **19. Years_From_2018**
- **Açıklama:** 2018'den itibaren geçen yıl sayısı
- **Hesaplama:** Year - 2018
- **Veri Tipi:** Integer
- **Aralık:** 0-6

#### **20. Is_Pandemic_Year**
- **Açıklama:** Pandemi yılı göstergesi
- **Hesaplama:** 1 if Year in [2020, 2021, 2022] else 0
- **Veri Tipi:** Integer (Binary)
- **Değerler:** 0 (Hayır), 1 (Evet)

#### **21. Is_Post_Pandemic**
- **Açıklama:** Pandemi sonrası dönem göstergesi
- **Hesaplama:** 1 if Year in [2023, 2024] else 0
- **Veri Tipi:** Integer (Binary)
- **Değerler:** 0 (Hayır), 1 (Evet)

#### **22. Year_Trend**
- **Açıklama:** Yıllık trend analizi
- **Hesaplama:** (Year - 2018) / 6 (normalize edilmiş)
- **Veri Tipi:** Float
- **Aralık:** 0-1

#### **23. Year_Cycle**
- **Açıklama:** Yıllık döngü analizi
- **Hesaplama:** sin(2 * π * (Year - 2018) / 7)
- **Veri Tipi:** Float
- **Aralık:** -1 ile 1 arası

#### **24. Year_Cycle_Cos**
- **Açıklama:** Yıllık döngü kosinüs analizi
- **Hesaplama:** cos(2 * π * (Year - 2018) / 7)
- **Veri Tipi:** Float
- **Aralık:** -1 ile 1 arası

#### **25. Country_Trend**
- **Açıklama:** Ülke bazında trend analizi
- **Hesaplama:** Ülke bazında yıllık ortalama değişim
- **Veri Tipi:** Float

#### **26. Population_Material_Interaction**
- **Açıklama:** Nüfus ve malzeme ayak izi etkileşimi
- **Hesaplama:** Population (Million) * Material_Footprint_Per_Capita
- **Veri Tipi:** Float

#### **27. Year_Population_Interaction**
- **Açıklama:** Yıl ve nüfus etkileşimi
- **Hesaplama:** Year * Population (Million)
- **Veri Tipi:** Float

---

#### **Coğrafi Özellikler (4 özellik)**

#### **28. Country_Encoded**
- **Açıklama:** Ülke kodlaması (sayısal)
- **Veri Tipi:** Integer
- **Aralık:** 0-19 (20 ülke için)

#### **29. Food Category_Encoded**
- **Açıklama:** Gıda kategorisi kodlaması (sayısal)
- **Veri Tipi:** Integer
- **Aralık:** 0-7 (8 kategori için)

#### **30. Continent_Encoded**
- **Açıklama:** Kıta kodlaması (sayısal)
- **Veri Tipi:** Integer
- **Aralık:** 0-5 (6 kıta için)

#### **31. Hemisphere_Encoded**
- **Açıklama:** Yarımküre kodlaması (sayısal)
- **Veri Tipi:** Integer
- **Aralık:** 0-1 (2 yarımküre için)

---

#### **Türetilmiş Özellikler (6 özellik)**

#### **32. Economic_Intensity**
- **Açıklama:** Ekonomik yoğunluk
- **Hesaplama:** Economic Loss (Million $) / Total Waste (Tons)
- **Veri Tipi:** Float
- **Birim:** Milyon USD/ton

#### **33. Waste_Trend**
- **Açıklama:** İsraf trendi
- **Hesaplama:** Yıllık israf değişim oranı
- **Veri Tipi:** Float
- **Birim:** Yüzde (%)

#### **34. Economic_Trend**
- **Açıklama:** Ekonomik trend
- **Hesaplama:** Yıllık ekonomik kayıp değişim oranı
- **Veri Tipi:** Float
- **Birim:** Yüzde (%)

#### **35. Category_Waste_Share**
- **Açıklama:** Kategori bazında israf payı
- **Hesaplama:** Kategori toplam israfı / Genel toplam israf
- **Veri Tipi:** Float
- **Birim:** Yüzde (%)

#### **36. Category_Economic_Share**
- **Açıklama:** Kategori bazında ekonomik pay
- **Hesaplama:** Kategori toplam ekonomik kaybı / Genel toplam ekonomik kayıp
- **Veri Tipi:** Float
- **Birim:** Yüzde (%)

#### **37. Sustainability_Score**
- **Açıklama:** Sürdürülebilirlik skoru
- **Hesaplama:** Çoklu faktör analizi (0-100 arası)
- **Veri Tipi:** Float
- **Birim:** Skor (0-100)
- **Yüksek Skor:** Daha sürdürülebilir

---

## 🎯 **HEDEF DEĞİŞKENLER**

### **Tahmin Edilecek 3 Ana Hedef:**

1. **Total Waste (Tons)** - Gıda israfı miktarı tahmini
2. **Economic Loss (Million $)** - Ekonomik kayıp tahmini  
3. **Carbon_Footprint_kgCO2e** - Karbon ayak izi tahmini

### **Model Performansı:**
- **Gradient Boosting:** R² = 0.96 (En iyi performans)
- **Random Forest:** R² = 0.94
- **Linear Regression:** R² = 0.88

---

## 📊 **VERİ KALİTESİ BİLGİLERİ**

### **Eksik Veri Analizi:**
- **Eksik Veri Oranı:** %0.1
- **Temizleme Yöntemi:** Forward fill ve backward fill

### **Aykırı Değer Tespiti:**
- **Yöntem:** IQR (Interquartile Range)
- **Tespit Edilen Aykırı Değer:** %2.3
- **İşlem:** Winsorization (üst ve alt %1)

### **Veri Tutarlılığı:**
- **Mantık Kontrolleri:** Tüm hesaplamalar doğrulandı
- **Birim Kontrolleri:** Tutarlı birim kullanımı
- **Aralık Kontrolleri:** Gerçekçi değer aralıkları

---

## 🔧 **VERİ İŞLEME SÜRECİ**

### **1. Veri Birleştirme:**
- Inner Join ile ülke bazında eşleştirme
- ISO kodları ile standartlaştırma

### **2. Özellik Mühendisliği:**
- 29 yeni özellik oluşturma
- Matematiksel hesaplamalar
- Kategorik kodlama

### **3. Veri Temizleme:**
- Eksik veri doldurma
- Aykırı değer işleme
- Veri tutarlılığı kontrolü

### **4. Ölçeklendirme:**
- StandardScaler ile normalizasyon
- Train/Test split (%80/%20)
- Cross-validation (3-fold)

---

**Doküman Tarihi:** 13 Ağustos 2025  
**Proje:** Ecolense Intelligence - Yapay Zeka Destekli Sürdürülebilirlik Platformu  
**Veri Seti:** ecolense_final_enriched_with_iso.csv  
**Toplam Değişken:** 37  
**Hedef Değişken:** 3
