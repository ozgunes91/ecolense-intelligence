# 📊 ECOLENSE INTELLIGENCE - VERİ SETİ HİKAYESİ

## 🌍 **Küresel Gıda İsrafı Veri Seti: 2018-2024**

### 📈 **Veri Seti Kapsamı ve Önemi**

**Ecolense Intelligence** projesi, küresel gıda israfı krizine veri odaklı çözümler üretmek amacıyla geliştirilmiş kapsamlı bir analitik platformdur. Projemizin temelini oluşturan veri seti, 2018-2024 yılları arasında 20 ülkeden toplanan 5,000 gözlemden oluşmaktadır.

### 🗂️ **Veri Kaynakları ve Birleştirme Süreci**

#### **Ana Veri Kaynakları:**
1. **Global Food Wastage Dataset (Kaggle)**
   - 8 temel değişken
   - 5,000 gözlem
   - 2018-2024 dönemi
   - 20 ülke kapsamı

2. **Material Footprint Dataset (Kaggle)**
   - 32 ek değişken
   - 197 ülke-yıl kombinasyonu
   - 1990-2021 dönemi
   - Sürdürülebilirlik metrikleri

#### **Veri Birleştirme Stratejisi:**
- **Inner Join** yöntemi ile ülke bazında eşleştirme
- ISO kodları ile standartlaştırma
- 37 değişkenli zenginleştirilmiş veri seti oluşturma

### 🔧 **Veri Zenginleştirme ve Özellik Mühendisliği**

#### **29 Yeni Özellik Oluşturma:**

**📊 Kişi Başı Metrikler (6 özellik):**
- `Waste_Per_Capita_kg`: Kişi başı gıda israfı
- `Economic_Loss_Per_Capita_USD`: Kişi başı ekonomik kayıp
- `Carbon_Per_Capita_kgCO2e`: Kişi başı karbon ayak izi

**⏰ Zamansal Özellikler (8 özellik):**
- `Years_From_2018`: 2018'den itibaren geçen yıl sayısı
- `Is_Pandemic_Year`: Pandemi yılı göstergesi
- `Is_Post_Pandemic`: Pandemi sonrası dönem
- `Year_Trend`: Yıllık trend analizi

**🌍 Coğrafi Özellikler (4 özellik):**
- `Continent`: Kıta bilgisi
- `Hemisphere`: Yarımküre bilgisi
- `Country_Encoded`: Ülke kodlaması

**📈 Türetilmiş Özellikler (6 özellik):**
- `Waste_Efficiency`: İsraf verimliliği
- `Economic_Intensity`: Ekonomik yoğunluk
- `Category_Waste_Share`: Kategori bazında israf payı
- `Category_Economic_Share`: Kategori bazında ekonomik pay

**🎯 Sürdürülebilirlik Metrikleri (5 özellik):**
- `Sustainability_Score`: Sürdürülebilirlik skoru (0-100)
- `Waste_Trend`: İsraf trendi
- `Economic_Trend`: Ekonomik trend

### 📊 **Veri Seti İstatistikleri**

#### **Temel Bilgiler:**
- **Toplam Gözlem:** 5,000
- **Zaman Aralığı:** 2018-2024 (7 yıl)
- **Ülke Sayısı:** 20
- **Gıda Kategorisi:** 8
- **Toplam Değişken:** 37

#### **Kapsanan Ülkeler:**
**Gelişmiş Ülkeler:** USA, Germany, France, UK, Japan, Canada, Australia
**Gelişmekte Olan:** China, India, Brazil, Indonesia, Mexico, Turkey
**Diğer:** Saudi Arabia, South Korea, Russia, Italy, Spain, South Africa, Argentina

#### **Gıda Kategorileri:**
1. **Fruits & Vegetables** (Meyve & Sebze)
2. **Prepared Food** (Hazır Gıda)
3. **Dairy Products** (Süt Ürünleri)
4. **Bakery Items** (Fırın Ürünleri)
5. **Beverages** (İçecekler)
6. **Meat & Seafood** (Et & Deniz Ürünleri)
7. **Frozen Food** (Dondurulmuş Gıda)
8. **Grains & Cereals** (Tahıl & Hububat)

### 🎯 **Veri Kalitesi ve Doğrulama**

#### **Veri Temizleme Süreci:**
- **Eksik Veri Analizi:** %0.1 eksik veri oranı
- **Aykırı Değer Tespiti:** IQR yöntemi ile tespit
- **Veri Tutarlılığı:** Mantık kontrolleri
- **Ölçeklendirme:** StandardScaler ile normalizasyon

#### **Veri Doğrulama:**
- **Cross-Validation:** 3-fold CV ile model performansı
- **Train/Test Split:** %80/%20 oranında bölme
- **Overfitting Kontrolü:** %1'den düşük fark
- **SHAP Analizi:** Model açıklanabilirliği

### 📈 **Kritik Bulgular ve İçgörüler**

#### **Toplam Değerler (2018-2024):**
- **Toplam Gıda İsrafı:** 125.3 milyon ton
- **Toplam Ekonomik Kayıp:** 125.2 milyar USD
- **Toplam Karbon Ayak İzi:** 313.3 milyon ton CO2e
- **Ortalama Sürdürülebilirlik Skoru:** 42.5/100

#### **Kategori Bazında Analiz:**
1. **Prepared Food:** 17.9M ton (14.3%)
2. **Beverages:** 16.4M ton (13.1%)
3. **Bakery Items:** 15.6M ton (12.4%)
4. **Fruits & Vegetables:** 15.5M ton (12.4%)
5. **Meat & Seafood:** 15.4M ton (12.3%)

#### **Ülke Bazında İsraf Oranları (2024):**
**En Yüksek İsraf:**
- Saudi Arabia: 127.3 kg/kişi
- India: 121.4 kg/kişi
- Australia: 118.8 kg/kişi

**En Düşük İsraf:**
- Brazil: 98.8 kg/kişi
- France: 99.6 kg/kişi
- UK: 99.6 kg/kişi

### 🤖 **Makine Öğrenmesi Modeli Performansı**

#### **Model Karşılaştırma Sonuçları:**
- **Gradient Boosting:** R² = 0.96 (En iyi performans)
- **Random Forest:** R² = 0.94
- **Linear Regression:** R² = 0.88

#### **Hedef Değişkenler:**
1. **Total Waste (Tons):** Gıda israfı tahmini
2. **Economic Loss (Million $):** Ekonomik kayıp tahmini
3. **Carbon_Footprint_kgCO2e:** Karbon ayak izi tahmini

### 🎯 **Veri Setinin Bilimsel Değeri**

#### **Araştırma Potansiyeli:**
- **Küresel Trend Analizi:** 7 yıllık zaman serisi
- **Ülke Karşılaştırması:** 20 ülke arası analiz
- **Kategori Bazında İnceleme:** 8 farklı gıda türü
- **Sürdürülebilirlik Değerlendirmesi:** Çok boyutlu analiz

#### **Politika Geliştirme:**
- **Hedefli Müdahale:** En kritik alanların belirlenmesi
- **Kaynak Optimizasyonu:** Etkili bütçe kullanımı
- **Öncelik Belirleme:** Acil eylem gerektiren konular
- **İzleme ve Değerlendirme:** Performans takibi

### 📊 **Veri Görselleştirme ve Dashboard**

#### **İnteraktif Platform Özellikleri:**
- **Gerçek Zamanlı Analiz:** Canlı veri işleme
- **Dinamik Grafikler:** Plotly tabanlı görselleştirme
- **Kullanıcı Etkileşimi:** Filtreleme ve seçim
- **Responsive Tasarım:** Tüm cihazlarda uyumlu

#### **Analitik Modüller:**
- **Kapsamlı Metrikler:** 4 ana KPI kartı
- **Etki Analizi:** Ekonomik, çevresel, sürdürülebilirlik
- **Model Performansı:** Karşılaştırmalı analiz
- **Hikaye Modu:** Problem → Analiz → Çözüm akışı

### 🌟 **Sonuç ve Gelecek Vizyonu**

Bu veri seti, küresel gıda israfı krizine karşı veri odaklı çözümler üretmek için tasarlanmış kapsamlı bir kaynaktır. 5,000 gözlem, 37 değişken ve 7 yıllık zaman serisi ile, gıda israfının ekonomik, çevresel ve sosyal boyutlarını analiz etme imkanı sunmaktadır.

**Ecolense Intelligence** platformu, bu veri setini kullanarak:
- %96 doğruluk oranında tahmin modelleri geliştirmiş
- 22 farklı analitik modül oluşturmuş
- Gerçek zamanlı dashboard platformu kurmuş
- Sürdürülebilir çözüm önerileri sunmuştur

Bu proje, gıda israfı krizine karşı teknoloji ve analitik gücünü birleştiren, geleceğe yönelik bir yaklaşım sergilemektedir.

---

**Proje:** Ecolense Intelligence - Yapay Zeka Destekli Sürdürülebilirlik Platformu  
**Tarih:** 13 Ağustos 2025  
**Veri Seti:** 5,000 gözlem, 37 değişken, 20 ülke, 8 kategori  
**Model Performansı:** R² = 0.96 (Gradient Boosting)
